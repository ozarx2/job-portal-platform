const handler = require('../server');

module.exports = async (req, res) => {
  return handler(req, res);
};


