const handler = require('../../backend/server');

module.exports = async (req, res) => {
  return handler(req, res);
};


