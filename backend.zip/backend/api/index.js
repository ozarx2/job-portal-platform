const server = require('../server');

module.exports = async (req, res) => {
  return server(req, res);
};


